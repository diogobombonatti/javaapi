package Test.api_test;

public class Carro {
    private String nome;

    public Carro() {
        // Construtor padrão necessário para o Jersey (framework de JAX-RS)
    }

    public Carro(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}