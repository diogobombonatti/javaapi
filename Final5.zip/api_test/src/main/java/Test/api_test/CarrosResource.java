package Test.api_test;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.util.Random;
import java.util.List;
import java.util.Arrays;

@Path("carros")
public class CarrosResource {

    private List<String> nomesCarros = Arrays.asList("Ferrari", "Tesla", "BMW", "Toyota", "Honda");

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Carro getCarro() {
        // Gerar um índice aleatório na lista de nomes de carros
        Random random = new Random();
        int indice = random.nextInt(nomesCarros.size());

        String nomeCarro = nomesCarros.get(indice);
        
        // Crie um objeto Carro com o nome do carro e retorne-o como JSON
        Carro carro = new Carro(nomeCarro);
        return carro;
    }
}